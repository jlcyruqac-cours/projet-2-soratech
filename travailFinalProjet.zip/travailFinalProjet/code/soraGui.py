import tkinter as tk
from PIL import Image, ImageTk
import sys
import pjsua as pj
import threading
import time

att= False
current_call = None



# Callback to receive events from account
class MyAccountCallback(pj.AccountCallback):

    def __init__(self, account=None):
        pj.AccountCallback.__init__(self, account)

    # Notification on incoming call
    def on_incoming_call(self, call):
        global current_call
        if current_call:
            call.answer(486, "Busy")
            return

        print("Incoming call from ", call.info().remote_uri)
        print("Press 'a' to answer")
        fen1 = tk.Tk()
        fen1.title("SoraPhone")
        fen1.iconbitmap("image/im.ico")
        fen1.config(background = '#41B77F')
        frame = tk.Frame(fen1,bg = '#41B77F' )
        label = tk.Label(frame,text="Appel venant de:"+ call.info().remote_uri,font=("Helvetica", 10),bg = '#41B77F',fg='white')
        label.pack()
        b1 = tk.Button(frame, text='ok',font=("Helvetica", 10),bg = 'white',fg='#41B77F',command = fen1.destroy)
        b1.pack(pady =25,fill = tk.X)
        frame.pack(expand=tk.YES)
        fen1.mainloop()
        current_call = call

        call_cb = MyCallCallback(current_call)
        current_call.set_callback(call_cb)

        current_call.answer(180)

    def wait(self):
        self.sem = threading.Semaphore(0)
        self.sem.acquire()

    def on_reg_state(self):
        if self.sem:
            if self.account.info().reg_status >= 200:
                self.sem.release()


# Callback to receive events from Call
class MyCallCallback(pj.CallCallback):

    def __init__(self, call=None):
        pj.CallCallback.__init__(self, call)

    # Notification when call state has changed
    def on_state(self):
        global current_call
        print("Call with", self.call.info().remote_uri, end=' ')
        print("is", self.call.info().state_text, end=' ')
        print("last code =", self.call.info().last_code, end=' ')
        print("(" + self.call.info().last_reason + ")")

        if self.call.info().state == pj.CallState.DISCONNECTED:
            current_call = None
            print('Current call is', current_call)

    # Notification when call's media state has changed.
    def on_media_state(self):
        if self.call.info().media_state == pj.MediaState.ACTIVE:
            # Connect the call to sound device
            call_slot = self.call.info().conf_slot
            pj.Lib.instance().conf_connect(call_slot, 0)
            pj.Lib.instance().conf_connect(0, call_slot)
            print("Media is now active")
        else:
            print("Media is inactive")


class soraGui():
    """interface graphique pour soraphone"""

    def __init__(self):
        self.LOG_LEVEL = 3
        # Logging callback
        self.window = tk.Tk()
        self.window.title("SoraPhone")
        self.window.geometry("400x650")
        self.window.iconbitmap("image/im.ico")
        self.window.config(background='#7383B1')
        self.window.resizable(width=False, height=False)
        self.textin = tk.StringVar()
        self.numero = ""
        self.clavier = tk.Frame(self.window, bg='#7383B1', bd=1)
        self.clavier.pack(expand=tk.YES)
        self.label = tk.Entry(self.window,font=("Helvetica", 30),textvar=self.textin,width=17,bd=5,bg='#7383B1', fg='white')
        self.label.place(x=10, y=10)
        self.creerWid()
        self.fields = 'utilisateur', 'mot de passe', 'serveur'
        self.lib = pj.Lib()
        self.window.mainloop()
        self.lib.init(log_cfg=pj.LogConfig(level=self.LOG_LEVEL, callback=self.log_cb))

        # Create UDP transport which listens to any available port
        self.transport = self.lib.create_transport(pj.TransportType.UDP,
                                         pj.TransportConfig(0))
        print("\nListening on", self.transport.info().host, end=' ')
        print("port", self.transport.info().port, "\n")



    def creerWid(self):
        """creer les widget pour l'interface"""
        barreMenu = tk.Menu(self.window)
        self.creerMenu(barreMenu)
        self.creerBouton()

    def make_call(self,uri):
        try:
            print("Making call to", uri)
            return self.acc.make_call(uri, cb=MyCallCallback())
        except pj.Error as e:
            print("Exception: " + str(e))
            return None

    def log_cb(self,level, str, len):
        print(str, end=' ')

    def creerMenu(self, barre_menu):
        """tous les command a changer"""
        file_menu = tk.Menu(barre_menu, tearoff=0)
        file_menu.add_command(label="connexion", command=self.connection)
        file_menu.add_command(label="Configuration", command=self.window.quit)
        file_menu.add_command(label="Quitter", command=self.window.quit)
        call_menu = tk.Menu(barre_menu, tearoff=0)
        call_menu.add_command(label="Repertoire", command=self.window.quit)
        call_menu.add_command(label="Journal", command=self.window.quit)
        call_menu.add_command(label="Groupes", command=self.window.quit)
        help_menu = tk.Menu(barre_menu, tearoff=0)
        help_menu.add_command(label="Outils", command=self.window.quit)
        help_menu.add_command(label="Aide", command=self.window.quit)
        barre_menu.add_cascade(label="Fichier", menu=file_menu)
        barre_menu.add_cascade(label="Appel", menu=call_menu)
        barre_menu.add_cascade(label="Aide", menu=help_menu)
        # configurer fenetre pour ajouter cette menu
        self.window.config(menu=barre_menu)

    def configImage(self, path):
        image = Image.open(path)
        image = image.resize((120, 80))
        image = ImageTk.PhotoImage(image)
        return image
    
    def appel(self):
        global current_call
        self.uri = "sip:" + self.label.get() + "@" + self.server
        if current_call:
            current_call.answer(200)
        elif self.label.get() == "*98":
            current_call = self.make_call(self.uri)
            time.sleep(10)
        else:
            current_call = self.make_call(self.uri)
            time.sleep(10)




    def creerBouton(self):
        btn=[]
        iter = 1
        for i in range(3):
           for j in range(3):
               btn.append(tk.Button(self.clavier,width = 5,text=str(iter),font=("Courrier", 30), bg='white',
                                         fg='#7383B1', command=lambda iter=iter :self.num(iter)).grid(row=i+1,column=j+1))
               iter += 1

        btnF = tk.Button(self.clavier, text='*', width=5, font=("Courrier", 30), bg='white', fg='#7383B1', command=lambda:self.num('*')).grid(
            row=4, column=1)
        self.call= self.configImage('image/im1.png')
        btnCall = tk.Button(self.clavier, text="appeler", image=self.call, font=("Courrier", 30), bg='white', fg='#7383B1',
                         command=self.appel).grid(row=5, column=1)
        self.endCall = self.configImage('image/im3.png')
        btnE = tk.Button(self.clavier, text="racrocher", image=self.endCall, font=("Courrier", 30), bg='white', fg='#7383B1',
                      command=self.racrocher).grid(row=5, column=3)
        self.message = self.configImage('image/im2.png')
        #, image=self.message
        btnM = tk.Button(self.clavier, text="Att", width=5, font=("Courrier", 30), bg='white', fg='#7383B1',
                      command=self.attente).grid(row=6, column=1)
        btnD = tk.Button(self.clavier, text='#', width=5, font=("Courrier", 30), bg='white', fg='#7383B1',
                              command=lambda:self.num('#')).grid(row=4, column=3)
        btn0 = tk.Button(self.clavier, text='0', width=5, font=("Courrier", 30), bg='white', fg='#7383B1',
                              command=lambda :self.num(0)).grid(row=4, column=2)
        btnSend = tk.Button(self.clavier, text="dtmf", width=5, font=("Courrier", 30), bg='white', fg='#7383B1',
                              command=self.sendDtmf).grid(row=6, column=3)
        btnC = tk.Button(self.clavier, text='C', width=5, font=("Courrier", 30), bg='white', fg='#7383B1',
                         command=self.clear).grid(row=5, column=2)
        self.clear()


    def transferer(self):
        dest_uri = "sip:" + self.label.get() + "@" + self.server
        self.acc.make_call(dest_uri, cb=MyCallCallback()).transfer_to_call(current_call,None,0)
    def racrocher(self):
        current_call.hangup()

    def attente(self):
        global att
        if not att:
            current_call.hold()
            att=True
        else:
            current_call.unhold()
            att=False

    def sendDtmf(self):
        digits = "sip:" + self.label.get() + "@" + self.server
        current_call.dial_dtmf(digits)

    def num(self,i):
        self.numero += str(i)
        self.textin.set(self.numero)

    def clear(self):
        self.numero = ""
        self.textin.set(self.numero)

    def connection(self):
        login = tk.Tk()
        login.title("connection")
        login.iconbitmap("image/im.ico")
        login.resizable(width=False,height=False)
        ents = self.makeForm(login)
        b1 = tk.Button(login, text='OK',
                       command=(lambda e=ents: self.fetch(e,login)))
        b1.pack(side=tk.LEFT, padx=5, pady=5)
        b2 = tk.Button(login, text='Annuler', command=login.destroy)
        b2.pack(side=tk.LEFT, padx=5, pady=5)


    def fetch(self,entries,fen):
        # Start the library
        self.server = entries[2][1].get()
        self.utilisateur = entries[0][1].get()
        self.mdp = entries[1][1].get()
        try:
            # Init library with default config and some customized
            # logging config.
            self.lib.init(log_cfg=pj.LogConfig(level=self.LOG_LEVEL, callback=self.log_cb))

            # Create UDP transport which listens to any available port
            self.transport = self.lib.create_transport(pj.TransportType.UDP,
                                             pj.TransportConfig(0))
            print("\nListening on", self.transport.info().host, end=' ')
            print("port", self.transport.info().port, "\n")

            # Start the library
            self.lib.start()

            # Create local account
            # acc = lib.create_account_for_transport(transport, cb=MyAccountCallback())
            self.acc = self.lib.create_account(pj.AccountConfig(self.server, self.utilisateur, self.mdp))

            self.acc_cb = MyAccountCallback(self.acc)
            self.acc.set_callback(self.acc_cb)
            self.acc_cb.wait()
            print("\n")
            print("Registration complete, status=", self.acc.info().reg_status,
                  "(" + self.acc.info().reg_reason + ")")

        except pj.Error as e:
            print("Exception: " + str(e))
            self.lib.destroy()
            lib = None

        fen.destroy()

    def makeForm(self,root):
        entries = []
        for field in self.fields:
            row =tk.Frame(root)
            lab = tk.Label(row, width=15, text=field, anchor='w')
            ent = tk.Entry(row)
            row.pack(side=tk.TOP, fill=tk.X, padx=5, pady=5)
            lab.pack(side=tk.LEFT)
            ent.pack(side=tk.RIGHT, expand=tk.YES, fill=tk.X)
            entries.append((field, ent))
        return entries




if __name__ == "__main__":
    camGUI = soraGui()